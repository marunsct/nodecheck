sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("nodecheck.repositories1.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map